<?
$title = '현대엘리베이터 - 실습01';
$company = '현대엘리베이터';
$tel = '1577-0603';
$email = 'jay@jay.com';
$c_num='607-09-98424';
$c_ceo='김주현';
$c_address='부산시 연제구 연산동 1234-567';
$c_slogan='현대엘리베이터가 만든 새로운 길을 따라 세상을 위로 넓어집니다.';
$e_slogan='The world expands along the new path created by Hyundai Elevator';
?>