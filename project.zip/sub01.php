<? include 'head.php';?>

<h2>회사소개</h2>

<? include 'tail.php';?>