<? include 'head.sub.php';?>


<main class="Main">
    <section class="MainVisual">
        <div class="MainSlider">
            <figure class="itm01"></figure>
            <figure class="itm02"></figure>
        </div>
        <div class="slogan">
            <h2>Lorem ipsum dolor sit amet.</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia enim quibusdam nostrum?</p>
        </div>
    </section>
    <section class="Customer">
        <ul class="container">
            <li>
                <h3>news &amp; notice<small><i class="xi-angle-right-thin"></i></small></h3>
                <ul>
                    <li>
                        <a href="">Lorem ipsum dolor sit amet. <span>2022.12.25</span></a>
                    </li>
                    <li>
                        <a href="">Lorem ipsum dolor sit amet. <span>2022.12.25</span></a>
                    </li>
                    <li>
                        <a href="">Lorem ipsum dolor sit amet. <span>2022.12.25</span></a>
                    </li>
                    <li>
                        <a href="">Lorem ipsum dolor sit amet. <span>2022.12.25</span></a>
                    </li>
                </ul>
            </li>
            <li>
                <div class="CuSlider">
                    <figure>
                        <img src="./img/product01.jpg" alt="">
                    </figure>
                    <figure>
                        <img src="./img/product02.jpg" alt="">
                    </figure>
                    <figure>
                        <img src="./img/product03.jpg" alt="">
                    </figure>
                </div>
            </li>
            <li>
                <h3>contact us</h3>
                <div class="contact">
                    <a href=""></a>
                    <a href=""></a>
                </div>
            </li>
        </ul>
    </section>
</main>

<? include 'tail.sub.php';?>